"use client"

import Header from "../src/app/components/Header"

export default function SyntheticV0PageForDeployment() {
  return <Header />
}